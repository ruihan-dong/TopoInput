
from __future__ import absolute_import
from __future__ import print_function

# Avoid importing "expensive" modules here (e.g. scipy), since this code is
# executed on PyMOL's startup. Only import such modules inside functions.

import os


def __init_plugin__(app=None):
    '''
    Add an entry to the PyMOL "Plugin" menu
    '''
    from pymol.plugins import addmenuitemqt
    addmenuitemqt('TopoInput', run_plugin_gui)


# global reference to avoid garbage collection of our dialog
dialog = None


def run_plugin_gui():
    '''
    Open our custom dialog
    '''
    global dialog

    if dialog is None:
        dialog = make_dialog()

    dialog.show()


def make_dialog():
    # entry point to PyMOL's API
    from pymol import cmd

    # pymol.Qt provides the PyQt5 interface, but may support PyQt4
    # and/or PySide as well
    from pymol.Qt import QtWidgets
    from pymol.Qt.utils import loadUi
    # from pymol.Qt.utils import getSaveFileNameWithExt

    # create a new Window
    dialog = QtWidgets.QDialog()

    # populate the Window from our *.ui file which was created with the Qt Designer
    uifile = os.path.join(os.path.dirname(__file__), 'TopoInput.ui')
    form = loadUi(uifile, dialog)

    # save input.json from 3 parts(config, layers, motifs)
    import json
    def input_json():
        # configs
        name = form.input_name.text()
        vall = form.input_vall.text()
        rbin = form.input_rbin.text()
        config_text = {"name": name,
                       "vall": vall,
                       "rbin": rbin}

        # layers
        layers = form.input_layers.toPlainText()
        layers = layers.replace("\n","")
        layers_text = json.loads(layers)
        
        # motifs
        motifs = form.input_motifs.toPlainText()
        motifs = motifs.replace("\n","")
        motifs_text = json.loads(motifs)

        # entire input.json
        input_text = {"config":config_text, "layers":layers_text, "motifs":motifs_text}
        
        # save input.json file
        with open('input.json', 'w') as f:
            json.dump(input_text, f, indent=4)
        return name

    # callback for the "Show Sketch" button
    def show_sketch():
        name = input_json()
        cmd.system('python -m topobuilder -input input.json -shape')
        cmd.delete('shapesketch')
        cmd.load(name + '/shapesketch.pdb')

    # callback for the "Build All" button
    def build_all():
        name = input_json()
        cmd.system('python -m topobuilder -input input.json')
        cmd.delete('shapesketch')
        cmd.load(name + '/shapesketch.pdb')

    # hook up button callbacks
    form.showsketch_button.clicked.connect(show_sketch)
    form.build_button.clicked.connect(build_all)

    return dialog